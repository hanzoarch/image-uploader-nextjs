import json
import os
import boto3
from botocore.exceptions import ClientError
from datetime import datetime
import logging
from urllib.parse import urlparse, urlunparse

# ロガーの設定
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# 環境変数の取得
BUCKET_NAME = os.environ['BUCKET_NAME']
UPLOAD_PATH = os.environ['UPLOAD_PATH']
REGION = os.environ['REGION']
DEFAULT_CONTENT_TYPE = os.environ.get('DEFAULT_CONTENT_TYPE', 'image/jpeg')

s3_client = boto3.client('s3', region_name=REGION)

def lambda_handler(event, context):
    # リクエストの詳細をログに出力
    logger.info(f"Received event: {json.dumps(event)}")
    logger.info(f"Context: {context}")

    try:
        # クエリパラメータからファイル名を取得
        query_params = event.get('queryStringParameters', {})
        logger.info(f"Query parameters: {query_params}")

        if not query_params:
            logger.error("No query parameters provided")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'No query parameters provided'})
            }

        file_name = query_params.get('file_name')
        content_type = query_params.get('content_type', DEFAULT_CONTENT_TYPE)

        if not file_name:
            logger.error("file_name is required")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'file_name is required'})
            }

        logger.info(f"Processing file: {file_name}, content type: {content_type}")

        # ファイル名に現在時刻を追加してユニークにする
        current_time = datetime.now().strftime("%Y%m%d%H%M%S")
        unique_file_name = f"{current_time}_{file_name}"

        # S3オブジェクトのキーを生成
        object_key = f"{UPLOAD_PATH}/{unique_file_name}"

        logger.info(f"Generated object key: {object_key}")

        # プリサインドURLを生成
        presigned_url = s3_client.generate_presigned_url('put_object',
                                                         Params={'Bucket': BUCKET_NAME,
                                                                 'Key': object_key,
                                                                 'ContentType': content_type},
                                                         ExpiresIn=3600)  # URLの有効期限は1時間

        # URLを解析して正しいエンドポイントに置換
        parsed_url = urlparse(presigned_url)
        new_netloc = f"{BUCKET_NAME}.s3-{REGION}.amazonaws.com"
        corrected_url = urlunparse(parsed_url._replace(netloc=new_netloc))

        logger.info(f"Original Presigned URL: {presigned_url}")
        logger.info(f"Corrected Presigned URL: {corrected_url}")

        response = {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'uploadUrl': corrected_url,
                'fileName': unique_file_name,
                'contentType': content_type
            })
        }
        logger.info(f"Returning response: {json.dumps(response)}")
        return response

    except ClientError as e:
        logger.error(f"ClientError occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
    except KeyError as e:
        logger.error(f"KeyError occurred: {str(e)}")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing required parameter: ' + str(e)})
        }
    except Exception as e:
        logger.error(f"Unexpected error occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'An unexpected error occurred'})
        }